# GoIT JavaScript course homework
